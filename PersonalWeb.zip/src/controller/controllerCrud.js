const config = require("../config/config.json");
const { Sequelize, QueryTypes } = require("sequelize");
const path = require("path");
const fs = require("fs");
const { myproject } = require("../models");
const sequelize = new Sequelize(config.development);

const addBlog = async (req, res) => {
  const { user } = req.session;
  const { title, content } = req.body;

  if (!user) {
    req.flash("error", "Silahkan Login Terlebih Dahulu");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/login");
  }

  if (!title) {
    req.flash("error", "title tidak boleh kosong");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-blog");
  }
  if (!content) {
    req.flash("error", "Content Tidak Boleh Kosong");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-blog");
  }

  if (content.length < 200) {
    req.flash("error", "content Minimal 200 karakter");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-blog");
  }

  if (!req.file) {
    req.flash("error", "Image Tidak Boleh Kosong");
    return res.redirect("/add-blog");
  }

  console.log(req.file);

  const image = "http://localhost:1706/image/" + req.file.filename;

  let uid = user.id;
  const query = `INSERT INTO public."Blogs" (title, content, image, user_id) VALUES ( :title, :content, :image, :uid)`;
  await sequelize.query(query, {
    type: QueryTypes.INSERT,
    replacements: { title, content, image, uid },
  });

  req.flash("success", "Berhasil Menambahkan Blog Baru");
  res.redirect("/blog");
};

const deleteBlog = async (req, res) => {
  const { id } = req.params;
  const { user } = req.session;

  let getImageById = `SELECT image, user_id from public."Blogs" WHERE id = ${id}`;
  let getImage = await sequelize.query(getImageById, {
    type: QueryTypes.SELECT,
  });

  if (!user) {
    req.flash("error", "Anda Harus Login Terlebih Dahulu");
    return res.redirect("/login");
  }

  if (user.id !== getImage[0].user_id) {
    req.flash("error", "Tidak Bisa Menghapus Yang Bukan Hak Anda");
    return res.redirect("/blog");
  }

  let img = getImage[0].image;
  let imgReplace = img.replace("http://localhost:1706/image/", "");
  console.log("Images:", imgReplace);

  const query = `DELETE FROM public."Blogs" WHERE id = ${id}`;
  const queryDelete = await sequelize.query(query, { type: QueryTypes.DELETE });

  if (queryDelete) {
    const fullPath = path.join(__dirname, "../uploads/", imgReplace);
    fs.unlink(fullPath, (err) => {});
  }

  req.flash("success", "Berhasil Menghapus Data Blog");
  res.redirect("/blog");
};

const editBlog = async (req, res) => {
  const { user } = req.session;
  const { id } = req.params;
  const { title, content } = req.body;

  const queryGetData = `SELECT * FROM public."Blogs" WHERE id = ${id}`;
  const sqlGetData = await sequelize.query(queryGetData, {
    type: QueryTypes.SELECT,
  });

  if (!user) {
    req.flash("error", "Silahkan Login Terlebih Dahulu");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/login");
  }

  if (user.id !== sqlGetData[0].user_id) {
    req.flash("error", "Tidak Bisa Mengubah Yang Bukan Hak Anda");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/blog");
  }

  let getImage = sqlGetData[0].image;
  let imageReplace = getImage.replace("http://localhost:1706/image/", "");

  let fileImage;
  if (req.file) {
    console.log("ImageBaru", req.file.filename);
    fileImage = "http://localhost:1706/image/" + req.file.filename;
    const fullPath = path.join(__dirname, "../uploads/", imageReplace);
    fs.unlink(fullPath, (err) => {});
  } else {
    fileImage = getImage;
  }

  const dates = new Date();
  const queryEditData = `UPDATE public."Blogs" SET title = :title, content = :content, image = :fileImage, "updatedAt" = :dates WHERE id = ${id}`;
  await sequelize.query(queryEditData, {
    type: QueryTypes.UPDATE,
    replacements: { title, content, fileImage, dates },
  });

  req.flash("success", "Berhasil Edit Data Blog");
  res.redirect("/blog");
};

const addMyProject = async (req, res) => {
  const { user } = req.session;
  const { title, content, react, node, next, php } = req.body;

  if (!user) {
    req.flash("error", "Silahkan Login Terlebih Dahulu");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/login");
  }

  if (!title) {
    req.flash("error", "Title TIdak Boleh Kosong");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-project");
  }
  if (!content) {
    req.flash("error", "Content Tidak Boleh Kosong");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-project");
  }

  if (content.length < 200) {
    req.flash("error", "Content Minimal 200 karakter");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-project");
  }

  if (!react && !node && !next && !php) {
    req.flash("error", "Minimal Pilih Salah Satu Technology");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/add-project");
  }

  let checkBox = "";
  if (react) {
    checkBox += ` ${react} `;
  }
  if (node) {
    checkBox += ` ${node} `;
  }
  if (next) {
    checkBox += ` ${next} `;
  }
  if (php) {
    checkBox += ` ${php} `;
  }

  if (!req.file) {
    req.flash("error", "Image Tidak Boleh Kosong");
    return res.redirect("/add-project");
  }
  const image = "http://localhost:1706/image/" + req.file.filename;

  const idUser = user.id;

  await myproject.create({
    title,
    content,
    technology: checkBox,
    image,
    user_id: idUser,
  });

  req.flash("success", "Berhasil Menambahkan Project Baru");
  res.redirect("/my-project");
};

const deleteMyProject = async (req, res) => {
  const { id } = req.params;
  const { user } = req.session;

  if (!user) {
    req.flash("error", "Silahkan Login Terlebih Dahulu");
    return res.redirect("/login");
  }

  const getImageById = await myproject.findOne({
    where: {
      id: id,
    },
  });

  if (user.id !== getImageById.user_id) {
    req.flash("error", "Tidak Bisa Menghapus Yang Bukan Hak Anda");
    return res.redirect("/my-project");
  }

  let getImage = getImageById.image;
  let imageReplace = getImage.replace("http://localhost:1706/image/", "");

  const deletes = await myproject.destroy({
    where: {
      id: id,
    },
  });

  if (deletes) {
    const fullPath = path.join(__dirname, "../uploads/", imageReplace);
    fs.unlink(fullPath, (err) => {});
  }

  req.flash("success", "Berhasil Menghapus Data Project");
  res.redirect("/my-project");
};

const editMyProject = async (req, res) => {
  const { id } = req.params;
  const { user } = req.session;
  const { title, content, react, node, next, php } = req.body;
  // console.log(react, node, next, php);

  if (!title) {
    req.flash("error", "Title TIdak Boleh Kosong");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect(`/edit-project/${id}`);
  }
  if (!content) {
    req.flash("error", "Content Tidak Boleh Kosong");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect(`/edit-project/${id}`);
  }

  if (content.length < 200) {
    req.flash("error", "Content Minimal 200 karakter");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect(`/edit-project/${id}`);
  }

  if (!react && !node && !next && !php) {
    req.flash("error", "Minimal Pilih Salah Satu Technology");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect(`/edit-project/${id}`);
  }

  let checkBox = "";
  if (react) {
    checkBox += ` ${react} `;
  }
  if (node) {
    checkBox += ` ${node} `;
  }
  if (next) {
    checkBox += ` ${next} `;
  }
  if (php) {
    checkBox += ` ${php} `;
  }

  const getDataById = await myproject.findOne({ where: { id: id } });

  if (!user) {
    req.flash("error", "Silahkan Login Terlebih Dahulu");
    if (req.file) {
      const fullPath = path.join(__dirname, "../uploads/", req.file.filename);
      fs.unlink(fullPath, (err) => {});
    }
    return res.redirect("/login");
  }

  if (user.id !== getDataById.user_id) {
    req.flash("error", "Tidak Bisa Mengedit Yang Bukan Hak Anda");
    return res.redirect("/my-project");
  }

  let getImage = getDataById.image;
  let imageReplace = getImage.replace("http://localhost:1706/image/", "");

  let fileImage;

  if (req.file) {
    fileImage = "http://localhost:1706/image/" + req.file.filename;
    const fullPath = path.join(__dirname, "../uploads/", imageReplace);
    fs.unlink(fullPath, (err) => {});
  } else {
    fileImage = getImage;
  }

  await myproject.update(
    {
      title: title,
      content: content,
      technology: checkBox,
      image: fileImage,
      updateAt: sequelize.fn("NOW"),
    },
    {
      where: {
        id: id,
      },
    }
  );

  req.flash("success", "Berhasil Mengubah Data Project");
  res.redirect(`/my-project`);
};

module.exports = {
  addBlog,
  deleteBlog,
  editBlog,
  addMyProject,
  deleteMyProject,
  editMyProject,
};
